//
//  SMKMirrorConnectionsDataSource.h
//  SketchMirrorKit
//
//  Created by Robin Speijer on 17-12-15.
//  Copyright © 2015 Awkward. All rights reserved.
//

#import <Foundation/Foundation.h>

/// The data source that is being used by SketchMirrorKit to get the needed information for streaming to the Mirror app. All methods are guaranteed to be called from the main queue.
@protocol SMKMirrorDataSource <NSObject>

/// The identifier of the current visible artboard in Sketch. This will be used for the initial connection setup with the Mirror app.
@property (readonly, nullable) NSString *currentArtboardIdentifier;

/// The content hierarchy for the Sketch file that is being sent to Sketch Mirror.
@property (readonly, nullable) NSDictionary *manifestContent;

/** 
 Render an the image for the given artboard identifier, within the specified rect at the specified scale.
 @param identifier The artboard identifier
 @param rect The rectangle of the artboard to render. If this is CGRectZero, the full artboard should be rendered.
 @param scale The scale of the artboard to render, relative to the user presentable 1x artboard representation. This means that the use of a iOS scale calculator is required to detect whether the user is designing at a 2x scale. If so, the artboard needs to be scaled down to be sent on a 1x scale.
 @param handler The completion handler to call with rendered interlaced PNG image data.
 */
- (void)renderImageForArtboardIdentifier:(nonnull NSString *)identifier
                                  inRect:(CGRect)rect
                                   scale:(CGFloat)scale
                                 context:(nullable id)context
                                 handler:(void (^ _Nonnull)(NSData * _Nullable imageData))handler;
@end
