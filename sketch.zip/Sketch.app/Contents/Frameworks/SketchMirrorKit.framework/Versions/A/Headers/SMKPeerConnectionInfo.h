//
//  SMKPeerConnectionState.h
//  SketchMirrorKit
//
//  Created by Robin Speijer on 17-02-16.
//  Copyright © 2016 Awkward. All rights reserved.
//

/// The connection state of a client.
typedef NS_ENUM(NSInteger, SMKPeerConnectionState) {
    /// The client is connected to Sketch. Content updates will be sent to the client.
    SMKPeerConnectionStateConnected,
    /// The connection to the client is being set up. Whenever the connection changes to connected, content is being sent.
    SMKPeerConnectionStateConnecting,
    /// There's no connection to the client. It should be possible to trigger connecting.
    SMKPeerConnectionStateNotConnected
};

/// The connection type to the client.
typedef NS_ENUM(NSInteger, SMKPeerConnectionType) {
    /// A USB connection. This type of connection does not have a connecting or notconnected state.
    SMKPeerConnectionTypeUSB,
    /// A WiFi connection. This connection currently works over WiFi, but it may support Bluetooth in the future.
    SMKPeerConnectionTypeNearby,
    /// A Mirror Web connection. This type of connection does not have a connecting state.
    SMKPeerConnectionTypeWeb,
    /// The connection type is unknown.
    SMKPeerConnectionTypeNone
};

@class SMKPeer;

/// Info about the connection to the specified Mirror client.
@interface SMKPeerConnectionInfo : NSObject <NSSecureCoding>

/// The connection state of the client.
@property (assign) SMKPeerConnectionState state;

/// The connection type of the client.
@property (assign) SMKPeerConnectionType type;

/// The connected peer, containing information about the client.
@property (strong) SMKPeer *peer;

@end
