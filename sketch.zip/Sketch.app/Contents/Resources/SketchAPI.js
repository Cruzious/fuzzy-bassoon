/*

This is a prototype Javascript API for Sketch.

The intention is to make something which is:

- native Javascript
- an easily understandable subset of the full internals of Sketch
- fully supported by Bohemian between releases (ie we try not to change it, unlike our internal API which we can and do change whenever we need to)
- still allows you to drop down to our internal API when absolutely necessary.

Comments and suggestions for this API are welcome - send them to developers@sketchapp.com.

All code (C) 2016 Bohemian Coding.


** PLEASE NOTE: this API is not final, and should be used for testing & feedback purposes only. **
** The idea eventually is that it's fixed - but until we've got the design right, it WILL change. **



Example script:

var sketch = context.api()

log(sketch.api_version)
log(sketch.version)
log(sketch.build)
log(sketch.full_version)


var document = sketch.selectedDocument;
var selection = document.selectedLayers;
var page = document.selectedPage;

var group = page.newGroup({frame:sketch.rectangle(0, 0, 100, 100), name:"Test"});
var rect = group.newShape({frame:sketch.rectangle(10, 10, 80, 80)});

log(selection.isEmpty);
selection.iterate(function(item) { log(item.name); } );

selection.clear();
log(selection.isEmpty);

group.select();
rect.addToSelection();

sketch.getStringFromUser("Test", "default");
sketch.getSelectionFromUser("Test", ["One", "Two"], 1);
sketch.message("Hello mum!");
sketch.alert("Title", "message");

*/

var __globals = this;
(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
'use strict';

var _Application = require('./Application.js');

/**
    Return a function that captures the context.
    When called, this function will initialise the API
    and return an Application object that provides access
    to all API functions.

    We do it like this to defer having to perform a lot
    of setup until context.api() is actually called -- thus
    scripts which don't call it at all suffer minimal overhead.
 */

function SketchAPIWithCapturedContext(context) {
    return function () {

        // The Application object effectively *is* the api -- all other
        // functions and objects can be accessed via it.

        return new _Application.Application(context);
    };
}

// HACK: expose the SketchAPIWithCapturedContext function globally
// I suspect that there's a better way to do this, but I've
// not yet figured it out.

// ********************************
// ## Sketch API.
//
// All code (C) 2016 Bohemian Coding.
// ********************************

__globals.SketchAPIWithCapturedContext = SketchAPIWithCapturedContext;

},{"./Application.js":2}],2:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Application = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _WrappedObject2 = require('./WrappedObject.js');

var _Document = require('./Document.js');

var _Rectangle = require('./Rectangle.js');

var _Group = require('./Group.js');

var _Text = require('./Text.js');

var _Image = require('./Image.js');

var _Shape = require('./Shape.js');

var _Artboard = require('./Artboard.js');

var _Page = require('./Page.js');

var _Tester = require('./Tester.js');

var _Layer = require('./Layer.js');

var _Selection = require('./Selection.js');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } // ********************************
// # Application.js
// # Sketch Javascript API.
//
// All code (C) 2016 Bohemian Coding.
// ********************************

/**
 Gives you access to Sketch, and provides access to:
 - the document model and the layer tree
 - metadata abound sketch itself
 - utilities for interacting with the user
 - access to the running plugin, it's resources and settings
 */

var Application = function (_WrappedObject) {
    _inherits(Application, _WrappedObject);

    /**
     Construct a new Application object.
     An instance of this class will be passed back to you when you
     initialise the API, so you generally shouldn't need to make new ones.
      @param context The context dictionary passed to the script when it was invoked.
     @return A new Application object.
     */

    function Application(context) {
        _classCallCheck(this, Application);

        /**
         Metadata about this version of Sketch.
         @type {dictionary}
         */
        var _this = _possibleConstructorReturn(this, Object.getPrototypeOf(Application).call(this, context));

        _this._metadata = MSApplicationMetadata.metadata();
        return _this;
    }

    /**
     The version of this API.
      @return A version string.
     */

    _createClass(Application, [{
        key: 'settingForKey',


        /**
         Return the value of a global setting for a given key.
         @param key The setting to look up.
         @return The setting value.
          This is equivalent to reading a setting for the currently
         running version of Sketch using the `defaults` command line tool,
         eg: defaults read com.bohemiancoding.sketch3 <key>
         */

        value: function settingForKey(key) {
            return NSUserDefaults.standardUserDefaults().objectForKey_(key);
        }

        /**
         Set the value of a global setting for a given key.
          @param key The setting to set.
         @param value The value to set it to.
          This is equivalent to writing a setting for the currently
         running version of Sketch using the `defaults` command line tool,
         eg: defaults write com.bohemiancoding.sketch3 <key> <value>
         */

    }, {
        key: 'setSettingForKey',
        value: function setSettingForKey(key, value) {
            NSUserDefaults.standardUserDefaults().setObject_forKey_(value, key);
        }

        /**
         Return a file URL pointing to a named resource in the plugin's Resources/
         folder.
          @param name The resource file name, including any file extension.
         @return The resource location, in the form "file://path/to/resource".
         */

    }, {
        key: 'resourceNamed',
        value: function resourceNamed(name) {
            return this._object.plugin.urlForResourceNamed_(name);
        }

        /**
         Shows a simple input sheet which displays a message, and asks for a single string
         input.
         @param msg The prompt message to show.
         @param initial The initial value of the input string.
         @return The string that the user input.
         */

    }, {
        key: 'getStringFromUser',
        value: function getStringFromUser(msg, initial) {
            var panel = MSModalInputSheet.alloc().init();
            var result = panel.runPanelWithNibName_ofType_initialString_label_("MSModalInputSheet", 0, initial, msg);
            return result;
        }

        /**
         Shows an input sheet which displays a popup with a series of options,
         from which the user is asked to choose.
          @param msg The prompt message to show.
         @param items A list of option items.
         @param selectedItemIndex The index of the item to select initially.
         @return An array with two items: [responseCode, selection].
          The result consists of a response code and a selection. The code will be
         one of NSAlertFirstButtonReturn or NSAlertSecondButtonReturn.
         The selection will be the integer index of the selected item.
         */

    }, {
        key: 'getSelectionFromUser',
        value: function getSelectionFromUser(msg, items, selectedItemIndex) {
            selectedItemIndex = selectedItemIndex || 0;

            var accessory = NSComboBox.alloc().initWithFrame(NSMakeRect(0, 0, 200, 25));
            accessory.addItemsWithObjectValues(items);
            accessory.selectItemAtIndex(selectedItemIndex);

            var alert = NSAlert.alloc().init();
            alert.setMessageText(msg);
            alert.addButtonWithTitle('OK');
            alert.addButtonWithTitle('Cancel');
            alert.setAccessoryView(accessory);

            var responseCode = alert.runModal();
            var sel = accessory.indexOfSelectedItem();

            return [responseCode, sel];
        }

        /**
         Output a message to the log console.
          @param {string} message The message to output.
         */

    }, {
        key: 'log',
        value: function log(message) {
            print(message);
        }

        /**
         Assert that a given condition is true.
         If the condition is false, throws an exception.
          @param condition An expression that is expected to evaluate to true if everything is ok.
         */

    }, {
        key: 'assert',
        value: function assert(condition) {
            if (!condition) {
                throw "Assert failed!";
            }
        }

        /**
         The selected document.
          If the user invoked the script explicitly (for example by selecting a menu item),
         this will be the document that they were working in at the time - ie the frontmost one.
         If the script was invoked as an action handler, this will be the document that the action
         occurred in.
          @return A Document object.
         */

    }, {
        key: 'newDocument',


        /**
         Create a new document and bring it to the front.
         @return The new document.
         */

        value: function newDocument() {
            var app = NSDocumentController.sharedDocumentController();
            app.newDocument_(this);
            return new _Document.Document(app.currentDocument(), this);
        }

        /**
         Show a small, temporary, message to the user.
         The message appears at the bottom of the selected document,
         and is visible for a short period of time. It should consist of a single
         line of text.
          @param {string} message The message to show.
         */

    }, {
        key: 'message',
        value: function message(_message) {
            this._object.document.showMessage(_message);
        }

        /**
         Show an alert with a custom title and message.
          @param {string} title The title of the alert.
         @param {string} message The text of the message.
          The alert is modal, so it will stay around until the user dismisses it
         by pressing the OK button.
         */

    }, {
        key: 'alert',
        value: function alert(title, message) {
            var app = NSApplication.sharedApplication();
            app.displayDialog_withTitle(title, message);
        }

        /**
         Return a new Rectangle object for a given x,y, width and height.
          @param {number} x The x coordinate of the top-left corner of the rectangle.
         @param {number} y The y coordinate of the top-left corner of the rectangle.
         @param {number} width The width of the rectangle.
         @param {number} height The height of the rectangle.
         @return The new Rectangle object.
         */

    }, {
        key: 'rectangle',
        value: function rectangle(x, y, width, height) {
            return new _Rectangle.Rectangle(x, y, width, height);
        }

        /**
         Return a lookup table of known mappings between Sketch model classes
         and our JS API wrapper classes.
          @return {dictionary} A dictionary with keys for the Sketch Model classes, and values for the corresponding API wrapper classes.
         */

    }, {
        key: 'wrapperMappings',
        value: function wrapperMappings() {
            var mappings = {
                MSLayerGroup: _Group.Group,
                MSPage: _Page.Page,
                MSArtboardGroup: _Artboard.Artboard,
                MSShapeGroup: _Shape.Shape,
                MSBitmapLayer: _Image.Image,
                MSTextLayer: _Text.Text
            };
            return mappings;
        }

        /**
         Return a wrapped version of a Sketch object.
         We don't know about *all* Sketch object types, but
         for some we will return a special subclass.
         The fallback position is just to return an instance of WrappedObject.
          @param {object} sketchObject The underlying sketch object that we're wrapping.
         @param {Document} inDocument The wrapped document that this object is part of.
         @return {WrappedObject} A javascript object (subclass of WrappedObject), which represents the Sketch object we were given.
        */

    }, {
        key: 'wrapObject',
        value: function wrapObject(sketchObject, inDocument) {
            var mapping = this.wrapperMappings();

            var jsClass = mapping[sketchObject.class()];
            if (!jsClass) {
                print("no mapped wrapper for " + sketchObject.class());
                jsClass = _WrappedObject2.WrappedObject;
            }

            return new jsClass(sketchObject, inDocument);
        }

        /**
         Return a list of tests to run for this class.
          We could do some fancy introspection here to derive the tests from
         the class, but for now we're opting for the simple approach.
          @return {dictionary} A dictionary containing the tests to run. Each key is the name of a test, each value is a function which takes a Tester instance.
         */

    }, {
        key: 'runUnitTests',


        /**
         Run all of our internal unit tests.
         Returns a dictionary indicating how many tests ran, passed, failed, and crashed,
         and a list of more detailed information for each failure.
          At some point we may switch to using Mocha or some other test framework, but for
         now we want to be able to invoke the tests from the Sketch side or from a plugin
         command, so it's simpler to use a simple test framework of our own devising.
         */

        value: function runUnitTests() {
            var tests = {
                "suites": {
                    "Application": Application.tests(),
                    "Artboard": _Artboard.Artboard.tests(),
                    "Document": _Document.Document.tests(),
                    "Group": _Group.Group.tests(),
                    "Image": _Image.Image.tests(),
                    "Layer": _Layer.Layer.tests(),
                    "Page": _Page.Page.tests(),
                    "Rectangle": _Rectangle.Rectangle.tests(),
                    "Selection": _Selection.Selection.tests(),
                    "Shape": _Shape.Shape.tests(),
                    "Text": _Text.Text.tests(),
                    "WrappedObject": _WrappedObject2.WrappedObject.tests()
                }
            };

            var tester = new _Tester.Tester(this);
            return tester.runUnitTests(tests);
        }
    }, {
        key: 'api_version',
        get: function get() {
            return "1.1";
        }

        /**
         The context that the API was created in.
         This is the traditional context argument that is
         passed to all plugin scripts when they are run.
          In general you should use the API to access Sketch
         rather than interacting with the context directly.
          @return A context dictionary.
         */

    }, {
        key: 'context',
        get: function get() {
            return this._object;
        }

        /**
         The version of Sketch that is running.
          @return The version as a string, eg "3.6".
         */

    }, {
        key: 'version',
        get: function get() {
            return this._metadata['appVersion'];
        }

        /**
         The exact build of Sketch that is running.
          @return The build number as a string, eg "15352".
         */

    }, {
        key: 'build',
        get: function get() {
            return this._metadata['build'];
        }

        /**
         Returns the full version of Sketch that is running
          @return {string} Version and build number as a string, eg "3.6 (15352)".
         */

    }, {
        key: 'full_version',
        get: function get() {
            return this.version + " (" + this.build + ")";
        }
    }, {
        key: 'selectedDocument',
        get: function get() {
            return new _Document.Document(this._object.document, this);
        }
    }], [{
        key: 'tests',
        value: function tests() {
            return {
                /** @test {Application} */
                "tests": {
                    /** @test {Application#api_version} */
                    testAPIVersion: function testAPIVersion(tester) {
                        tester.assertEqual(tester.application.api_version, "1.1");
                    },


                    /** @test {Application#version} */
                    testApplicationVersion: function testApplicationVersion(tester) {
                        tester.assertEqual(tester.application.version, "1.0");
                    },


                    /** @test {Application#wrapObject} */
                    testWrapObject: function testWrapObject(tester) {
                        var classesToTest = [MSLayerGroup, MSPage, MSArtboardGroup, MSShapeGroup, MSBitmapLayer, MSTextLayer];
                        var mappings = tester.application.wrapperMappings();
                        for (var index in classesToTest) {
                            var classToTest = classesToTest[index];
                            var frame = NSMakeRect(0, 0, 100, 100);
                            var object = classToTest.alloc().initWithFrame(frame);
                            var mockDocument = {};
                            var wrapped = tester.application.wrapObject(object, mockDocument);
                            tester.assertEqual(wrapped._object, object);
                            tester.assertEqual(wrapped._document, mockDocument);
                            tester.assertEqual(wrapped.class, mappings[classToTest].class);
                        }
                    }
                }
            };
        }
    }]);

    return Application;
}(_WrappedObject2.WrappedObject);

exports.Application = Application;

},{"./Artboard.js":3,"./Document.js":4,"./Group.js":5,"./Image.js":6,"./Layer.js":7,"./Page.js":8,"./Rectangle.js":9,"./Selection.js":10,"./Shape.js":11,"./Tester.js":12,"./Text.js":13,"./WrappedObject.js":14}],3:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Artboard = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Layer2 = require("./Layer.js");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } // ********************************
// # Artboard.js
// # Sketch Javascript API.
//
// All code (C) 2016 Bohemian Coding.
// ********************************

/**
    A Sketch artboard.
*/

var Artboard = exports.Artboard = function (_Layer) {
    _inherits(Artboard, _Layer);

    /**
        Make a new artboard.
         @param artboard {MSArtboardGroup} The underlying MSArtboardGroup model object from Sketch.
        @param document The document that the artboard belongs to.
    */

    function Artboard(artboard, document) {
        _classCallCheck(this, Artboard);

        return _possibleConstructorReturn(this, Object.getPrototypeOf(Artboard).call(this, artboard, document));
    }

    /**
        Is this an artboard?
         All Layer objects respond to this method, but only Artboard objects return true.
         @return true for instances of Artboard, false for any other layer type.
    */

    _createClass(Artboard, [{
        key: "isArtboard",
        get: function get() {
            return true;
        }

        /**
         Return a list of tests to run for this class.
          @return {dictionary} A dictionary containing the tests to run. Each key is the name of a test, each value is a function which takes a Tester instance.
         */

    }], [{
        key: "tests",
        value: function tests() {
            return {
                "tests": {
                    "test something": function testSomething(tester) {
                        tester.assert(true);
                    }
                }
            };
        }
    }]);

    return Artboard;
}(_Layer2.Layer);

},{"./Layer.js":7}],4:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Document = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _WrappedObject2 = require('./WrappedObject.js');

var _Layer = require('./Layer.js');

var _Page = require('./Page.js');

var _Selection = require('./Selection.js');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } // ********************************
// # Document.js
// # Sketch Javascript API.
//
// All code (C) 2016 Bohemian Coding.
// ********************************

/**
A Sketch document.
*/

var Document = exports.Document = function (_WrappedObject) {
  _inherits(Document, _WrappedObject);

  /**
  Make a new document object.
   @param {MSDocument} document The underlying MSDocument object.
  @param {Application} application The application object.
   Note that constructing one of these doesn't actually create
  a Sketch document. Instead you pass in the underlying MSDocument
  that this object represents.
   If you do want to create a new document, you can do so with Application#newDocument.
  */

  function Document(document, application) {
    _classCallCheck(this, Document);

    /**
    The application that this document belongs to.
     @type {Application}
    */

    var _this = _possibleConstructorReturn(this, Object.getPrototypeOf(Document).call(this, document));

    _this._application = application;
    return _this;
  }

  /**
  Return a wrapped version of a Sketch object.
  We don't know about *all* Sketch object types, but
  for some we will return a special subclass.
  The fallback position is just to return an instance of WrappedObject.
   @param {object} sketchObject The underlying sketch object that we're wrapping.
  @return {WrappedObject} A javascript object (subclass of WrappedObject), which represents the Sketch object we were given.
  */

  _createClass(Document, [{
    key: 'wrapObject',
    value: function wrapObject(sketchObject, inDocument) {
      return this._application.wrapObject(sketchObject, this);
    }

    /**
    The layers that the user has selected.
     @return {Selection} A selection object representing the layers that the user has selected.
    */

  }, {
    key: 'layerWithID',


    /**
    Find the first layer in this document which has the given id.
     @return {Layer} A layer object, if one was found.
    */

    value: function layerWithID(layer_id) {
      var layer = this._object.documentData().layerWithID_(layer_id);
      if (layer) return new _Layer.Layer(layer, this);
    }

    /**
    Find the first layer in this document which has the given name.
     @return {Layer} A layer object, if one was found.
    */

  }, {
    key: 'layerNamed',
    value: function layerNamed(layer_name) {
      // As it happens, layerWithID also matches names, so we can implement
      // this method in the same way as layerWithID.
      // That might not always be true though, which is why the JS API splits
      // them into separate functions.

      var layer = this._object.documentData().layerWithID_(layer_name);
      if (layer) return new _Layer.Layer(layer, this);
    }

    /**
    Center the view of the document window on a given layer.
     @param {Layer} layer The layer to center on.
    */

  }, {
    key: 'centerOnLayer',
    value: function centerOnLayer(layer) {
      this._object.currentView().centerRect_(layer._object.rect());
    }

    /**
    Return a list of tests to run for this class.
     @return {dictionary} A dictionary containing the tests to run. Each key is the name of a test, each value is a function which takes a Tester instance.
    */

  }, {
    key: 'selectedLayers',
    get: function get() {
      return new _Selection.Selection(this._object);
    }

    /**
    The current page that the user has selected.
     @return {Page} A page object representing the page that the user is currently viewing.
    */

  }, {
    key: 'selectedPage',
    get: function get() {
      return new _Page.Page(this._object.currentPage(), this);
    }

    /**
    Returns a list of the pages in this document.
     @return {list} The pages.
    */

  }, {
    key: 'pages',
    get: function get() {
      var result = [];
      var loop = this._object.pages().objectEnumerator();
      var item;
      while (item = loop.nextObject()) {
        result.push(new _Page.Page(item, this));
      }
      return result;
    }
  }], [{
    key: 'tests',
    value: function tests() {
      return {
        "tests": {
          "test something": function testSomething(tester) {
            tester.assert(true);
          }
        }
      };
    }
  }]);

  return Document;
}(_WrappedObject2.WrappedObject);

},{"./Layer.js":7,"./Page.js":8,"./Selection.js":10,"./WrappedObject.js":14}],5:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Group = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Layer2 = require("./Layer.js");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } // ********************************
// # Group.js
// # Sketch Javascript API.
//
// All code (C) 2016 Bohemian Coding.
// ********************************

/**
  Represents a group of layers.
 */

var Group = exports.Group = function (_Layer) {
    _inherits(Group, _Layer);

    /**
      Make a new group object.
       @param group {MSLayerGroup} The underlying model object from Sketch.
      @param document The document that the group belongs to.
    */

    function Group(group, document) {
        _classCallCheck(this, Group);

        return _possibleConstructorReturn(this, Object.getPrototypeOf(Group).call(this, group, document));
    }

    /**
        Is this an group?
         All Layer objects respond to this method, but only Groups or things that inherit from groups return true.
         @return {bool} true for instances of Group, false for any other layer type.
    */

    _createClass(Group, [{
        key: "is_group",
        value: function is_group() {
            return true;
        }

        /**
         Return a list of tests to run for this class.
          @return {dictionary} A dictionary containing the tests to run. Each key is the name of a test, each value is a function which takes a Tester instance.
         */

    }], [{
        key: "tests",
        value: function tests() {
            return {
                "tests": {
                    "test something": function testSomething(tester) {
                        tester.assert(true);
                    }
                }
            };
        }
    }]);

    return Group;
}(_Layer2.Layer);

},{"./Layer.js":7}],6:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Image = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Layer2 = require("./Layer.js");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } // ********************************
// # Image.js
// # Sketch Javascript API.
//
// All code (C) 2016 Bohemian Coding.
// ********************************

/**
  Represents an image layer.
 */

var Image = exports.Image = function (_Layer) {
  _inherits(Image, _Layer);

  /**
    Make a new image layer object.
     @param {MSBitmapLayer} layer The underlying model object from Sketch.
    @param {Document} document The document that the bitmap layer belongs to.
  */

  function Image(layer, document) {
    _classCallCheck(this, Image);

    return _possibleConstructorReturn(this, Object.getPrototypeOf(Image).call(this, layer, document));
  }

  /**
      Is this an image layer?
       All Layer objects respond to this method, but only image layers return true.
       @return {bool} true for instances of Image, false for any other layer type.
  */

  _createClass(Image, [{
    key: "isImage",
    get: function get() {
      return true;
    }

    /**
      Set the layer's image to the contents of the image file at a given URL.
       @param {NSURL} url The location of the image to use.
    */

  }, {
    key: "imageURL",
    set: function set(url) {
      var image = NSImage.alloc().initWithContentsOfURL_(url);
      var imageData = MSImageData.alloc().initWithImage_convertColorSpace_(image, true);
      this._object.setImage_(imageData);
    }

    /**
     Return a list of tests to run for this class.
      @return {dictionary} A dictionary containing the tests to run. Each key is the name of a test, each value is a function which takes a Tester instance.
     */

  }], [{
    key: "tests",
    value: function tests() {
      return {
        "tests": {
          "test something": function testSomething(tester) {
            tester.assert(true);
          }
        }
      };
    }
  }]);

  return Image;
}(_Layer2.Layer);

},{"./Layer.js":7}],7:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Layer = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _WrappedObject2 = require('./WrappedObject.js');

var _Rectangle = require('./Rectangle.js');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } // ********************************
// # Layer.js
// # Sketch Javascript API.
//
// All code (C) 2016 Bohemian Coding.
// ********************************

/**
  Represents a Sketch layer.
 */

var Layer = exports.Layer = function (_WrappedObject) {
  _inherits(Layer, _WrappedObject);

  /**
    Make a new layer object.
     @param {MSLayer} layer The underlying model object from Sketch.
    @param {Document} document The document that the layer belongs to.
  */

  function Layer(layer, document) {
    _classCallCheck(this, Layer);

    /** @type {Document} The document that this layer belongs to. */
    var _this = _possibleConstructorReturn(this, Object.getPrototypeOf(Layer).call(this, layer));

    _this._document = document;
    return _this;
  }

  /**
    The name of the layer.
     @return {string} The layer's name.
  */

  _createClass(Layer, [{
    key: 'duplicate',


    /**
      Duplicate this layer.
      A new identical layer will be inserted into the parent of this layer.
       @return {Layer} A new layer identical to this one.
    */

    value: function duplicate() {
      return self._document.wrapObject(this._object.duplicate());
    }

    /**
        Is this a page?
         All Layer objects respond to this method, but only pages return true.
         @return {bool} true for instances of Group, false for any other layer type.
    */

  }, {
    key: '_addWrappedLayerWithProperties',


    /**
      Add a new wrapped layer object to represent a Sketch layer.
      Apply any supplied properties to the wrapper (which will apply
      them in turn to the wrapped layer).
       @param {MSLayer} newLayer The underlying Sketch layer object.
      @param {dictionary} properties The properties to apply.
      @param {string} wrapper The name of wrapper class to use.
      @return {Layer} The wrapped layer object.
    */

    value: function _addWrappedLayerWithProperties(newLayer, properties, wrapper) {
      if (newLayer) {
        // add the Sketch object to this layer
        var layer = this._object;
        layer.addLayers_(NSArray.arrayWithObject_(newLayer));

        // make a Javascript wrapper object for the new layer
        var wrapper = this._document.wrapObject(newLayer);

        // apply properties, via the wrapper
        for (var p in properties) {
          wrapper[p] = properties[p];
        }

        return wrapper;
      }
    }

    /**
      Extract the frame to use for a layer from some properties.
      If the frame wasn't supplied in the properties, we return a default value instead.
       @param {dictionary} properties The properties to use when looking for a frame value.
      @return {Rectangle} The frame rectangle to use.
    */

  }, {
    key: '_frameForLayerWithProperties',
    value: function _frameForLayerWithProperties(properties) {
      var frame = properties.frame;
      if (frame) {
        delete properties["frame"];
      } else {
        frame = new _Rectangle.Rectangle(0, 0, 100, 100);
      }
      return frame;
    }

    /**
        Returns a newly created shape, which has been added to this layer,
        and sets it up using the supplied properties.
         @param {dictionary} properties Properties to apply to the shape.
        @return {Shape} the new shape.
    */

  }, {
    key: 'newShape',
    value: function newShape(properties) {
      var frame = this._frameForLayerWithProperties(properties);
      var newLayer = MSShapeGroup.shapeWithBezierPath_(NSBezierPath.bezierPathWithRect_(frame.asCGRect()));
      return this._addWrappedLayerWithProperties(newLayer, properties, "Shape");
    }

    /**
        Returns a newly created text layer, which has been added to this layer,
        and sets it up using the supplied properties.
         @param {dictionary} properties Properties to apply to the text layer.
        @return {Text} the new text layer.
    */

  }, {
    key: 'newText',
    value: function newText(properties) {
      var frame = this._frameForLayerWithProperties(properties);
      var newLayer = MSTextLayer.alloc().initWithFrame_(frame.asCGRect());
      newLayer.adjustFrameToFit();
      return this._addWrappedLayerWithProperties(newLayer, properties, "Text");
    }

    /**
        Returns a newly created group, which has been added to this layer,
        and sets it up using the supplied properties.
         @param {dictionary} properties Properties to apply to the group.
        @return {Group} the new group.
    */

  }, {
    key: 'newGroup',
    value: function newGroup(properties) {
      var frame = this._frameForLayerWithProperties(properties);
      var newLayer = MSLayerGroup.alloc().initWithFrame_(frame.asCGRect());
      return this._addWrappedLayerWithProperties(newLayer, properties, "Group");
    }

    /**
        Returns a newly created image layer, which has been added to this layer,
        and sets it up using the supplied properties.
         @param {dictionary} properties Properties to apply to the layer.
        @return {Image} the new image layer.
    */

  }, {
    key: 'newImage',
    value: function newImage(properties) {
      var frame = this._frameForLayerWithProperties(properties);
      var newLayer = MSBitmapLayer.alloc().initWithFrame_(frame.asCGRect());
      return this._addWrappedLayerWithProperties(newLayer, properties, "Image");
    }

    /**
        Remove this layer from its parent.
    */

  }, {
    key: 'remove',
    value: function remove() {
      var parent = this._object.parentGroup();
      if (parent) {
        parent.removeLayer_(this._object);
      }
    }

    /**
        Select the layer.
        This will clear the previous selection. Use addToSelection() if you wish
        to preserve the existing selection.
    */

  }, {
    key: 'select',
    value: function select() {
      this._object.select_byExpandingSelection(true, false);
    }

    /**
        Deselect this layer.
        Any other layers that were previously selected will remain selected.
    */

  }, {
    key: 'deselect',
    value: function deselect() {
      this._object.select_byExpandingSelection(false, true);
    }

    /**
        Add this layer to the selected layers.
        Any other layers that were previously selected will remain selected.
    */

  }, {
    key: 'addToSelection',
    value: function addToSelection() {
      this._object.select_byExpandingSelection(true, true);
    }

    /**
        Perform a function for every sub-layer inside this one.
        The function will be passed a single argument each time it is
        invoked - which will be an object representing the sub-layer.
         @param block {function} The function to execute for each layer.
    */

  }, {
    key: 'iterate',
    value: function iterate(block) {
      var loop = this._object().layers().objectEnumerator();
      while (item = loop.nextObject()) {
        var layer = self._document.wrapObject(item);
        block(layer);
      }
    }

    /**
     Return a list of tests to run for this class.
      @return {dictionary} A dictionary containing the tests to run. Each key is the name of a test, each value is a function which takes a Tester instance.
     */

  }, {
    key: 'name',
    get: function get() {
      return this._object.name();
    }

    /**
      Set the name of the layer.
       @param {string} name The new name.
    */

    ,
    set: function set(value) {
      this._object.setName_(value);
    }

    /**
      The frame of the layer.
      This is given in coordinates that are local to the parent of the layer.
       @return {Rectangle} The layer's frame.
    */

  }, {
    key: 'frame',
    get: function get() {
      var f = this._object.frame();
      return new _Rectangle.Rectangle(f.x(), f.y(), f.width(), f.height());
    }

    /**
      Set the frame of the layer.
      This will move and/or resize the layer as appropriate.
      The new frame should be given in coordinates that are local to the parent of the layer.
       @param {Rectangle} frame - The new frame of the layer.
    */

    ,
    set: function set(value) {
      var f = this._object.frame();
      f.setRect_(NSMakeRect(value.x, value.y, value.width, value.height));
    }
  }, {
    key: 'isPage',
    get: function get() {
      return false;
    }

    /**
        Is this an artboard?
         All Layer objects respond to this method, but only Artboard objects return true.
         @return true for instances of Artboard, false for any other layer type.
    */

  }, {
    key: 'isArtboard',
    get: function get() {
      return false;
    }

    /**
        Is this an group?
         All Layer objects respond to this method, but only Groups or things that inherit from groups return true.
         @return {bool} true for instances of Group, false for any other layer type.
    */

  }, {
    key: 'isGroup',
    get: function get() {
      return false;
    }

    /**
        Is this a text layer?
         All Layer objects respond to this method, but only text layers return true.
         @return {bool} true for instances of Group, false for any other layer type.
    */

  }, {
    key: 'isText',
    get: function get() {
      return false;
    }

    /**
        Is this a shape layer?
         All Layer objects respond to this method, but only shape layers (rectangles, ovals, paths etc) return true.
         @return {bool} true for instances of Group, false for any other layer type.
    */

  }, {
    key: 'isShape',
    get: function get() {
      return false;
    }

    /**
        Is this an image layer?
         All Layer objects respond to this method, but only image layers return true.
         @return {bool} true for instances of Group, false for any other layer type.
    */

  }, {
    key: 'isImage',
    get: function get() {
      return false;
    }
  }], [{
    key: 'tests',
    value: function tests() {
      return {
        "tests": {
          "test something": function testSomething(tester) {
            tester.assert(true);
          }
        }
      };
    }
  }]);

  return Layer;
}(_WrappedObject2.WrappedObject);

},{"./Rectangle.js":9,"./WrappedObject.js":14}],8:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Page = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Layer2 = require("./Layer.js");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } // ********************************
// # Page.js
// # Sketch Javascript API.
//
// All code (C) 2016 Bohemian Coding.
// ********************************

/**
  Represents a Page in a Sketch document.
 */

var Page = exports.Page = function (_Layer) {
    _inherits(Page, _Layer);

    /**
      Make a new page object.
       @param {MSPage} page The underlying model object from Sketch.
      @param document The document that the page belongs to.
    */

    function Page(page, document) {
        _classCallCheck(this, Page);

        var _this = _possibleConstructorReturn(this, Object.getPrototypeOf(Page).call(this, page));

        _this._document = document;
        return _this;
    }

    /**
        Is this a page?
         All Layer objects respond to this method, but only pages return true.
         @return {bool} true for instances of Group, false for any other layer type.
    */

    _createClass(Page, [{
        key: "newArtboard",


        /**
            Returns a newly created artboard, which has been added to this page,
            and sets it up using the supplied properties.
             @param properties {dictionary} Properties to apply to the artboard.
            @return {Artboard} the new artboard.
        */

        value: function newArtboard(properties) {
            var frame = this._frameForLayerWithProperties(properties);
            var newLayer = MSArtboardGroup.alloc().initWithFrame_(frame.asCGRect());
            return this._addWrappedLayerWithProperties(newLayer, properties, "Artboard");
        }

        /**
         Return a list of tests to run for this class.
          @return {dictionary} A dictionary containing the tests to run. Each key is the name of a test, each value is a function which takes a Tester instance.
         */

    }, {
        key: "isPage",
        get: function get() {
            return true;
        }
    }], [{
        key: "tests",
        value: function tests() {
            return {
                "tests": {
                    "test something": function testSomething(tester) {
                        tester.assert(true);
                    }
                }
            };
        }
    }]);

    return Page;
}(_Layer2.Layer);

},{"./Layer.js":7}],9:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

// ********************************
// # Rectangle.js
// # Sketch Javascript API.
//
// All code (C) 2016 Bohemian Coding.
// ********************************

/**
  Represents a rectangle.
 */

var Rectangle = exports.Rectangle = function () {

  /**
    Return a new Rectangle object for a given x,y, width and height.
     @param {number} x The x coordinate of the top-left corner of the rectangle.
    @param {number} y The y coordinate of the top-left corner of the rectangle.
    @param {number} width The width of the rectangle.
    @param {number} height The height of the rectangle.
    @return The new Rectangle object.
  */

  function Rectangle(x, y, width, height) {
    _classCallCheck(this, Rectangle);

    /**
      The x coordinate of the top-left corner of the rectangle.
      @type {number}
    */

    this.x = x;

    /**
      The y coordinate of the top-left corner of the rectangle.
      @type {number}
    */

    this.y = y;

    /**
      The width of the rectangle.
      @type {number}
    */

    this.width = width;

    /**
      The height of the rectangle.
      @type {number}
    */

    this.height = height;
  }

  /**
    Return the Rectangle as a CGRect.
     @return {CGRect} The rectangle.
  */

  _createClass(Rectangle, [{
    key: "asCGRect",
    value: function asCGRect() {
      return CGRectMake(this.x, this.y, this.width, this.height);
    }

    /**
     Return a list of tests to run for this class.
      @return {dictionary} A dictionary containing the tests to run. Each key is the name of a test, each value is a function which takes a Tester instance.
     */

  }], [{
    key: "tests",
    value: function tests() {
      return {
        "tests": {
          "test something": function testSomething(tester) {
            tester.assert(true);
          }
        }
      };
    }
  }]);

  return Rectangle;
}();

},{}],10:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Selection = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _WrappedObject2 = require('./WrappedObject.js');

var _Layer = require('./Layer.js');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } // ********************************
// # Selection.js
// # Sketch Javascript API.
//
// All code (C) 2016 Bohemian Coding.
// ********************************

/**
    Represents the layers that the user has selected.
*/

var Selection = exports.Selection = function (_WrappedObject) {
    _inherits(Selection, _WrappedObject);

    /**
      Make a new Selection object.
       @param {Document} document The document that the selection relates to.
    */

    function Selection(document) {
        _classCallCheck(this, Selection);

        return _possibleConstructorReturn(this, Object.getPrototypeOf(Selection).call(this, document));
    }

    /**
        Does the selection contain any layers?
         @return {boolean} true if the selection is empty.
    */

    _createClass(Selection, [{
        key: 'iterateAndClear',


        /**
            Perform an action once for each layer in the selection, then clear it.
             @param {function(layer: Layer)} block The function to execute for each layer.
        */

        value: function iterateAndClear(block) {
            var layers = this._object.selectedLayers();
            this.clear();
            this._iterateWithLayers(layers, block);
        }

        /**
            Perform an action once for each layer in the selection.
             @param {function(layer: Layer)} block The function to execute for each layer.
        */

    }, {
        key: 'iterate',
        value: function iterate(block) {
            var layers = this._object.selectedLayers();
            this._iterateWithLayers(layers, block);
        }

        /**
            Clear the selection.
        */

    }, {
        key: 'clear',
        value: function clear() {
            this._object.currentPage().deselectAllLayers();
        }

        /**
            Iterate through a bunch of layers, executing a block.
             @param {array} layers The layers to iterate over.
            @param {function(layer: Layer)} block The function to execute for each layer.
        */

    }, {
        key: '_iterateWithLayers',
        value: function _iterateWithLayers(layers, block) {
            var loop = layers.objectEnumerator();
            var item;
            while (item = loop.nextObject()) {
                var layer = this._object._application.wrapObject(item, this._object);
                block(layer);
            }
        }

        /**
         Return a list of tests to run for this class.
          @return {dictionary} A dictionary containing the tests to run. Each key is the name of a test, each value is a function which takes a Tester instance.
         */

    }, {
        key: 'isEmpty',
        get: function get() {
            return this._object.selectedLayers().count() == 0;
        }
    }], [{
        key: 'tests',
        value: function tests() {
            return {
                "tests": {
                    "test something": function testSomething(tester) {
                        tester.assert(true);
                    }
                }
            };
        }
    }]);

    return Selection;
}(_WrappedObject2.WrappedObject);

},{"./Layer.js":7,"./WrappedObject.js":14}],11:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Shape = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Layer2 = require("./Layer.js");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } // ********************************
// # Shape.js
// # Sketch Javascript API.
//
// All code (C) 2016 Bohemian Coding.
// ********************************

/**
  Represents a shape layer (a rectangle, oval, path, etc).
 */

var Shape = exports.Shape = function (_Layer) {
    _inherits(Shape, _Layer);

    /**
      Make a new shape object.
       @param shape {MSShapeGroup} The underlying model object from Sketch.
      @param document The document that the shape belongs to.
    */

    function Shape(shape, document) {
        _classCallCheck(this, Shape);

        return _possibleConstructorReturn(this, Object.getPrototypeOf(Shape).call(this, shape, document));
    }

    /**
        Is this a shape layer?
         All Layer objects respond to this method, but only shape layers (rectangles, ovals, paths etc) return true.
         @return {bool} true for instances of Group, false for any other layer type.
    */

    _createClass(Shape, [{
        key: "isShape",
        get: function get() {
            return true;
        }

        /**
         Return a list of tests to run for this class.
          @return {dictionary} A dictionary containing the tests to run. Each key is the name of a test, each value is a function which takes a Tester instance.
         */

    }], [{
        key: "tests",
        value: function tests() {
            return {
                "tests": {
                    "test something": function testSomething(tester) {
                        tester.assert(true);
                    }
                }
            };
        }
    }]);

    return Shape;
}(_Layer2.Layer);

},{"./Layer.js":7}],12:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

// ********************************
// # Tester.js
// # Sketch Javascript API.
//
// All code (C) 2016 Bohemian Coding.
// ********************************


/**
    Very simple unit testing utility.


    At some point we may switch to using Mocha or some other test framework, but for
    now we want to be able to invoke the tests from the Sketch side or from a plugin
    command, so it's simpler to use a simple test framework of our own devising.
*/

var Tester = exports.Tester = function () {

    /**
     Make a new tester.
      */

    function Tester(application) {
        _classCallCheck(this, Tester);

        /** @type {array} List of failures in the currently running test. */
        this._testFailures = [];

        /** @type {Application} The application that is running these tests. */
        this._application = application;

        /** @type {number} The number of tests we've run. */
        this._ran = 0;

        /** @type {array} The names of the tests that have passed. */
        this._passes = [];

        /** @type {array} Failure information for each test that has failed. */
        this._failures = [];
    }

    /**
     Assert that a condition is true.
     If the assertion fails, the failure is recorded for later reporting by the tester.
     
     @param {bool} condition The condition we're asserting.
     @param {string} description A description of the test.
     */

    _createClass(Tester, [{
        key: "assert",
        value: function assert(condition, description) {
            if (!condition) {
                if (!description) description = "";
                this._testFailures.push(description);
            }
        }

        /**
         Assert that two values are equal.
         If the assertion fails, the failure is recorded for later reporting by the tester.
          @param v1 The first value to compare.
         @param v2 The second value to compare.
        */

    }, {
        key: "assertEqual",
        value: function assertEqual(v1, v2) {
            if (v1 != v2) {
                this._testFailures.push(v1 + " != " + v2);
            }
        }

        /**
            The application instance that we're running the tests for.
            This is the instance associated with the script context that launched the tests.
         
            @return {Application} The application object.
         */

    }, {
        key: "runUnitTests",


        /**
         Run a collection of tests.
         
         The method takes a dictionary describing the tests to run.
         The dictionary can contain two keys:
         - suites: this is a dictionary of sub-collections, each of which is recursively run by calling this method again.
         - tests: this is a dictionary of test functions, each of which is executed.
         
         The test functions are passed this tester object when they are executed, and should use the assertion methods on it
         to perform tests.
          @param {dictionary} specification A dictionary describing the tests to run. See discussion.
         @param {string} suiteName The name of the suite, if we're running a sub-collection. This will be null for the top level tests.
         @return {dictionary} Returns a dictionary indicating how many tests ran, and a list of the passed, failed, and crashed tests.
         */

        value: function runUnitTests(specification, suiteName) {
            var suites = specification.suites;
            for (var suite in suites) {
                this.runUnitTests(suites[suite], suite);
            }

            var tests = specification.tests;
            for (var name in tests) {
                var test = tests[name];
                this._ran++;
                this._testFailures = [];
                var result = test(this);
                var fullName = suiteName ? suiteName + " : " + name : name;
                if (this._testFailures.length > 0) {
                    this._failures.push({ "name": fullName, "reasons": this._testFailures });
                } else {
                    this._passes.push(fullName);
                }
            }

            return {
                "ran": this._ran,
                "crashes": [],
                "failures": this._failures,
                "passes": this._passes
            };
        }
    }, {
        key: "application",
        get: function get() {
            return this._application;
        }
    }]);

    return Tester;
}();

},{}],13:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Text = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Layer2 = require("./Layer.js");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } // ********************************
// # Text.js
// # Sketch Javascript API.
//
// All code (C) 2016 Bohemian Coding.
// ********************************

// ## Constants

var BCTextBehaviourFlexibleWidth = 0;
var BCTextBehaviourFixedWidth = 1;

/**
  Represents a text layer.
 */

var Text = exports.Text = function (_Layer) {
  _inherits(Text, _Layer);

  /**
    Make a new text object.
     @param {MSTextLayer} text The underlying model object from Sketch.
    @param {Document} document The document that the text layer belongs to.
  */

  function Text(text, document) {
    _classCallCheck(this, Text);

    return _possibleConstructorReturn(this, Object.getPrototypeOf(Text).call(this, text, document));
  }

  /**
      Is this a text layer?
       All Layer objects respond to this method, but only text layers return true.
       @return {bool} true for instances of Group, false for any other layer type.
  */

  _createClass(Text, [{
    key: "resizeToFitContents",


    /**
      Adjust the frame of the layer to fit its contents.
    */

    value: function resizeToFitContents() {
      this._object.adjustFrameToFit();
    }

    /**
     Return a list of tests to run for this class.
      @return {dictionary} A dictionary containing the tests to run. Each key is the name of a test, each value is a function which takes a Tester instance.
     */

  }, {
    key: "isText",
    get: function get() {
      return true;
    }

    /**
      The text of the layer.
    */

  }, {
    key: "text",
    get: function get() {
      return this._object.stringValue;
    }

    /**
      Set the text of the layer.
       @param {string} value The text to use.
    */

    ,
    set: function set(value) {
      this._object.stringValue = value;
    }

    /**
      Set the font of the layer to an NSFont object.
       @param {NSFont} value The font to use.
    */

  }, {
    key: "font",
    set: function set(value) {
      this._object.font = value;
    }

    /**
       Set the font of the layer to the system font at a given size.
        @param {number} size The system font size to use.
    */

  }, {
    key: "systemFontSize",
    set: function set(size) {
      this._object.font = NSFont.systemFontOfSize_(size);
    }

    /**
       Set the alignment of the layer.
        @param {number} mode The alignment mode to use.
    */

  }, {
    key: "alignment",
    set: function set(mode) {
      this._object.textAlignment = mode;
    }

    /**
     Set the layer to be fixed width or variable width.
      @param {bool} value Whether the layer should be fixed width (true) or variable width (false).
    */

  }, {
    key: "fixedWidth",
    set: function set(value) {
      if (value) {
        this._object.textBehaviour = BCTextBehaviourFixedWidth;
      } else {
        this._object.textBehaviour = BCTextBehaviourFlexibleWidth;
      }
    }
  }], [{
    key: "tests",
    value: function tests() {
      return {
        "tests": {
          "test something": function testSomething(tester) {
            tester.assert(true);
          }
        }
      };
    }
  }]);

  return Text;
}(_Layer2.Layer);

},{"./Layer.js":7}],14:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

// ********************************
// # WrappedObject.js
// # Sketch Javascript API.
//
// All code (C) 2016 Bohemian Coding.
// ********************************

/**
  Base class for all objects that
  wrap Sketch classes.

*/

var WrappedObject = exports.WrappedObject = function () {

  /**
    Return a new wrapped object for a given Sketch model object.
     @param {Object} object - The Sketch model object to wrap.
  */

  function WrappedObject(object) {
    _classCallCheck(this, WrappedObject);

    /** @type {Object} The underlying Sketch model object that we are wrapping. */
    this._object = object;
  }

  /**
    Returns the object ID of the wrapped Sketch model object.
     @return {string} The id.
  */

  _createClass(WrappedObject, [{
    key: "id",
    get: function get() {
      return this._object._objectID();
    }

    /**
     Return a list of tests to run for this class.
      @return {dictionary} A dictionary containing the tests to run. Each key is the name of a test, each value is a function which takes a Tester instance.
     */

  }], [{
    key: "tests",
    value: function tests() {
      return {
        "tests": {
          "test something": function testSomething(tester) {
            tester.assert(true);
          }
        }
      };
    }
  }]);

  return WrappedObject;
}();

},{}]},{},[1]);
